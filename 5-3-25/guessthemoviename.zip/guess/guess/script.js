function check1()
{
    var text = document.getElementById('input_1').value
    document.getElementById("input_2").focus()
    document.getElementById("input_1").disabled = true
    if(text=='a' || text=='A')
    {
        document.getElementById('hint_1').src='image1.png'
    }
    else{
        document.getElementById('hint_1').src='image2.png'
    }
}
function check2()
{
    var text = document.getElementById('input_2').value
    document.getElementById("input_3").focus()
    document.getElementById("input_2").disabled = true
    
    if(text=='b' || text=='B')
    {
        document.getElementById('hint_2').src='image1.png'
    }
    else{
        document.getElementById('hint_2').src='image2.png'
    }
}
function check3()
{
    var text = document.getElementById('input_3').value
    document.getElementById("input_4").focus()
    document.getElementById("input_3").disabled = true
    
    if(text=='c' || text=='C')
    {
        document.getElementById('hint_3').src='image1.png'
    }
    else{
        document.getElementById('hint_3').src='image2.png'
    }
}
function check4()
{
    var text = document.getElementById('input_4').value
    document.getElementById("input_4").blur()
    document.getElementById("input_4").disabled = true
    
    if(text=='d' || text=='D')
    {
        document.getElementById('hint_4').src='image1.png'
    }
    else{
        document.getElementById('hint_4').src='image2.png'
    }
}