import logo from './logo.svg';
import './App.css';
import Header from './Header';
import Footer from './Footer';
import Home from './Home';
import About from './About';

function App() {
  return (
    <>
    <Header/>
    <Home/>
    {/* <About/> */}
    {/* <About/> */}
    <Footer/>
    
    </>
  );
}

export default App;
